package com.example.clinicaOdontologica.service;

import com.example.clinicaOdontologica.persistence.entities.Domicilio;

public interface DomicilioService extends CrudService<Domicilio> {
}
