package com.example.clinicaOdontologica.service;

import com.example.clinicaOdontologica.model.OdontologoDTO;

public interface OdontologoService extends CrudService<OdontologoDTO> {
}
